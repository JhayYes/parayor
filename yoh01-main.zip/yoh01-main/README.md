# Pedido de namoro
Este é um site feito puramente em HTML, CSS e JavaScript que fiz para pedir em namoro a minha atual ex (é, infelizmente não deu certo).

Ele foi pensado para ser aberto no celular, e idealmente com o Chrome.
Eu fiz ele, pedi para ela acessar o site enquanto eu ficava do lado olhando a reação dela. Na última parte da apresentação onde diz "agora olhe para mim" é quando eu pedi ela em namoro. Foi bem bonito e ela amou.
Caso tenha problemas com o celular, você também pode abrir em uma SmartTV. Fica bem legal também!

Você pode trocar as imagens, os textos e reinventar todo o layout para se adequar às suas frases e ao seu pedido.
